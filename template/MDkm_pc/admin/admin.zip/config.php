<?php

//decode by nige112
session_start();
error_reporting(0);
include "mdym.config.php";
define("SYSPATH", $mdym["path"]);