<?php
 $mdym =  array (
  'load' => 
  array (
    'state' => '1',
    'time' => '3',
    'appurl' => 'https://xydai.cn',
    'url' => 'https://xydai.cn',
    'img' => 'https://ae03.alicdn.com/kf/H14bd65ef4a5d44ce84597d023008a6dbG.jpg',
    'yjurl' => 'https://xydai.cn',
  ),
  'free' => 
  array (
    'state' => '1',
    'num' => '4',
  ),
  'logo' => '/MDassets/img/logo.png',
  'type' => 
  array (
    'bannerpc' => '7',
    'bannerwap' => '8',
    'free' => '6',
  ),
  'index' => 
  array (
    'num' => '8',
  ),
  'join' => 'https://xydai.cn',
  'serve' => 'http://wpa.qq.com/msgrd?v=3&uin=1747597875&site=qq&menu=yes',
  'email' => 'mailto:123456@test.cn',
  'search' => '永久网址 mdym.net',
  'down' => 
  array (
    'ios' => 'https://ae03.alicdn.com/kf/H892a9900947a437797e27242afe060a4z.jpg',
    'android' => 'https://ae03.alicdn.com/kf/H892a9900947a437797e27242afe060a4z.jpg',
  ),
  'gonggao' => '<h2 style="margin-top: 10px; color: rgb(255, 255, 255); font-size: 20px; font-weight: 300; text-align: center;">请牢记最新域名</h2>
			<div style="margin-top: 20px; color: rgb(255, 255, 255); font-size: 18px; font-weight: 300; text-align: center;">
				国内主用域名：mdym.net
			</div>
			<div style="margin-top: 20px; color: rgb(255, 255, 255); font-size: 18px; font-weight: 300; text-align: center;">
				国内备用域名：xydai.cn
			</div>',
  'usergonggao' => '1.请牢记本站永久地址mdym.net xydai.cn。
2.qq浏览器，百度浏览器可能无法正常使用本网站。
3.推荐使用UC浏览器访问，播放更快！！！
4.充值未到账请联系在线客服！！！',
);
?>